import java.util.HashMap;
import java.util.Map;

import com.simple8583.client.SimpleClient;
import com.simple8583.factory.XmlReader;
import com.simple8583.key.SimpleConstants;


public class Client {

    public static void main(String[] args) throws Exception {
        Map<String,String> requestMap = new HashMap<String,String>();
        requestMap.put("tpdu","6000000000");//受卡方系统跟踪号	n6
	requestMap.put("VersionNo","602200000000");//受卡方系统跟踪号	n6
	requestMap.put(SimpleConstants.MTI,"0800");
	requestMap.put("11","156240");//受卡方系统跟踪号	n6
	requestMap.put("12","010101");//受卡方所在地时间	n6
	requestMap.put("13","1213");//受卡方所在地日期	n4
	requestMap.put("32","12345678");//受理方标识码	n..11
	requestMap.put("37","121301010101");//检索参考号	an12
	requestMap.put("39","00");//应答码	an2
	requestMap.put("41","12345678");//受卡机终端标识码	ans8
	requestMap.put("42","123456789012345");//受卡方标识码	ans15
	requestMap.put("60","00161213001");//自定义域	n…011
	requestMap.put("62", "123456789012345678901234");//终端密钥	b...040
	requestMap.put("63", "CUP");//终端密钥	b...040
        String ip = "192.168.0.138";
        int port = 8080;
        int timeout = 15000;//15s超时

        String macKey = "helloSimple8583";
        SimpleClient simpleClient = new SimpleClient(ip,port,timeout);
        simpleClient.setMacKey(macKey);
        XmlReader xmlReader = new XmlReader("simple8583.xml");
        Map<String,String> resultMap = simpleClient.sendToBank(requestMap,xmlReader);
        System.out.println(resultMap);
    }
}
