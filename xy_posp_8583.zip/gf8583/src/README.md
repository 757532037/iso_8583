Simple Iso8583 FrameWork

Encountering Iso8583 when I access in bank's interface. I complete a framework to simplify the difficulty in development. I publish it on github to help you to enhance your efficiency and have more time to get rest and play.

This version is built upon pure j2se, no external dependency, it is  small and flexible. There is also have another Maven Version to use.Here is the configuration:

Please contact <a href="mailto:out_lier@126.com">Magic Joey</a> when you have any problem or want to join me in open source.
