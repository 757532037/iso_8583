import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBException;

import com.simple8583.client.AbstractClient;
import com.simple8583.client.SimpleClient;
import com.simple8583.factory.XmlReader;
import com.simple8583.key.SimpleConstants;
import com.simple8583.util.EncodeUtil;


public class Server {


   
    
    public static void main(String[] args) throws Exception {
	    Map<String,String> requestMap = new HashMap<String,String>();
	    requestMap.put("tpdu","6000000000");//受卡方系统跟踪号	n6
		requestMap.put("VersionNo","602200000000");//受卡方系统跟踪号	n6
		requestMap.put(SimpleConstants.MTI,"0810");
		requestMap.put("11","156240");//受卡方系统跟踪号	n6
		requestMap.put("12","010101");//受卡方所在地时间	n6
		requestMap.put("13","1213");//受卡方所在地日期	n4
		requestMap.put("32","12345678");//受理方标识码	n..11
		requestMap.put("37","121301010101");//检索参考号	an12
		requestMap.put("39","00");//应答码	an2
		requestMap.put("41","12345678");//受卡机终端标识码	ans8
		requestMap.put("42","123456789012345");//受卡方标识码	ans15
		requestMap.put("60","00161213001");//自定义域	n…011
		requestMap.put("62", "123456789012345678901234");//终端密钥	b...040
	
	
//	Map<String,String> requestMap = new HashMap<String,String>();
//	requestMap.put(SimpleConstants.TPDU, "6000000000");
//	requestMap.put(SimpleConstants.VERSION_NO, "600200000000");
//	requestMap.put(SimpleConstants.MTI,"0800");
//	requestMap.put("11","156240");//受卡方系统跟踪号	n6
//	requestMap.put("12","010101");//受卡方所在地时间	n6
//	requestMap.put("13","1213");//受卡方所在地日期	n4
//	requestMap.put("32","12345678");//受理方标识码	n..11
//	requestMap.put("37","121301010101");//检索参考号	an12
//	requestMap.put("39","00");//应答码	an2
//	requestMap.put("41","12345678");//受卡机终端标识码	ans8
//	requestMap.put("42","123456789012345");//受卡方标识码	ans15
//	requestMap.put("60","00161213001");//自定义域	n…011
//	requestMap.put("62", "123456789012345678901234");//终端密钥	b...040
//	requestMap.put("63", "CUP");//终端密钥	b...040

//		requestMap.put("tpdu","6000000000");//受卡方系统跟踪号	n6
//		requestMap.put("VersionNo","602200000000");//受卡方系统跟踪号	n6
//		requestMap.put(SimpleConstants.MTI,"0800");
//		requestMap.put("11","156240");//受卡方系统跟踪号	n6
//		requestMap.put("12","010101");//受卡方所在地时间	n6
//		requestMap.put("13","1213");//受卡方所在地日期	n4
//		requestMap.put("32","12345678");//受理方标识码	n..11
//		requestMap.put("37","121301010101");//检索参考号	an12
//		requestMap.put("39","00");//应答码	an2
//		requestMap.put("41","12345678");//受卡机终端标识码	ans8
//		requestMap.put("42","123456789012345");//受卡方标识码	ans15
//		requestMap.put("60","00161213001");//自定义域	n…011
//		requestMap.put("62", "123456789012345678901234");//终端密钥	b...040
//		requestMap.put("63", "CUP");//终端密钥	b...040
		SimpleClient simpleClient = new SimpleClient("127.0.0.1",8080,150);
		XmlReader xmlReader = new XmlReader("simple8583.xml");
		byte[] resultMap = simpleClient.getBytes(requestMap,xmlReader);
		System.out.println("发送报文：" + EncodeUtil.hex(resultMap));
			ServerSocket serverSocket = new ServerSocket(8080);
			Socket socket = null;
			byte[] buf = null;
			while(true){
			    socket = serverSocket.accept();
			  //两字节长度
				byte[] lenbuf = new byte[2];
				while (socket != null && socket.isConnected()) {
					if (socket.getInputStream().read(lenbuf) == 2) {
						//计算前两位报文所表示的报文长度
						int size = computeLength(lenbuf);
						//新建对应长度字节数组
						buf = new byte[size];
						//读取数据
						socket.getInputStream().read(buf);
						break;
					}
				}
				System.out.println("接收报文：" +EncodeUtil.hex(lenbuf)+ EncodeUtil.hex(buf));
				socket.getOutputStream().write(resultMap);
				socket.getOutputStream().flush();
				System.out.println("发送报文：" + EncodeUtil.hex(resultMap));
			    Thread.sleep(200);
			}
    }
	static int computeLength(byte[] lenBts){
		if(lenBts.length!=2){
			throw new IllegalArgumentException("字节长度不正确，预期值为2，实际值为："+lenBts.length);
		}
		// int size = ((lenbuf[0] & 0xff) << 8) | (lenbuf[1] & 0xff);//普通的长度编码
		return (lenBts[0] & 0xff) * 256
				+ (lenBts[1] & 0xff);
	}
}
